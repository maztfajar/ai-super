import { useState, useEffect, useRef } from 'react'
import { useModelsStore } from '../store'
import { api } from '../hooks/useApi'
import { copyToClipboard } from "../utils/clipboard"
import toast from 'react-hot-toast'
import {
  Save, RefreshCw, CheckCircle2, XCircle, Eye, EyeOff,
  RotateCcw, Send, AlertCircle, ChevronDown, ChevronUp,
  Play, Square, Wifi, WifiOff, Webhook, Plus, Trash2,
  Copy, Check, Code, Zap, Globe,
} from 'lucide-react'
import clsx from 'clsx'

const intApi = {
  status:          () => api.get('/integrations/status'),
  saveKey:         (p, f) => api.post('/integrations/save-key', { provider: p, fields: f }),
  reloadModels:    () => api.post('/integrations/reload-models'),
  restart:         () => api.post('/integrations/restart'),
  testTelegram:    () => api.post('/integrations/telegram/test'),
  testOllama:      () => api.post('/integrations/ollama/test'),
  testSumopod:     () => api.post('/integrations/sumopod/test'),
  pollingStatus:   () => api.get('/integrations/telegram/polling-status'),
  startPolling:    () => api.post('/integrations/telegram/start-polling'),
  stopPolling:     () => api.post('/integrations/telegram/stop-polling'),
  listWebhooks:    () => api.listWebhooks(),
  createWebhook:   (d) => api.createWebhook(d),
  updateWebhook:   (id, d) => api.updateWebhook(id, d),
  deleteWebhook:   (id) => api.deleteWebhook(id),
  testWebhook:     (id) => api.testWebhook(id),
  webhookTemplates:() => api.webhookTemplates(),
  // Custom model providers
  listCustomModels:     () => api.listCustomModels(),
  addCustomModel:       (d) => api.addCustomModel(d),
  deleteCustomModel:    (id) => api.deleteCustomModel(id),
  testCustomModel:      (id) => api.testCustomModel(id),
  testCustomConnection: (d) => api.testCustomConnection(d),
}

// ── Primitives ────────────────────────────────────────────────
function Label({ children }) {
  return <label className="block text-[10px] text-ink-3 mb-1 uppercase tracking-wider font-medium">{children}</label>
}

function SecretInput({ label, value, onChange, placeholder, hint, disabled }) {
  const [show, setShow] = useState(false)
  return (
    <div>
      {label && <Label>{label}</Label>}
      <div className="relative">
        <input type={show ? 'text' : 'password'} value={value} onChange={e => onChange(e.target.value)}
          placeholder={placeholder} disabled={disabled}
          autoComplete="new-password"
          className="w-full bg-bg-2 border border-border-2 rounded-lg px-3 py-2 text-xs text-ink placeholder-ink-3 outline-none focus:border-accent pr-9 font-mono disabled:opacity-50"/>
        <button type="button" onClick={() => setShow(!show)}
          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-ink-3 hover:text-ink">
          {show ? <EyeOff size={13}/> : <Eye size={13}/>}
        </button>
      </div>
      {hint && <p className="text-[10px] text-ink-3 mt-1">{hint}</p>}
    </div>
  )
}

function TextInput({ label, value, onChange, placeholder, hint, mono, disabled }) {
  return (
    <div>
      {label && <Label>{label}</Label>}
      <input type="text" value={value} onChange={e => onChange(e.target.value)}
        placeholder={placeholder} disabled={disabled}
        className={clsx('w-full bg-bg-2 border border-border-2 rounded-lg px-3 py-2 text-xs text-ink placeholder-ink-3 outline-none focus:border-accent disabled:opacity-50', mono && 'font-mono')}/>
      {hint && <p className="text-[10px] text-ink-3 mt-1">{hint}</p>}
    </div>
  )
}

function Textarea({ label, value, onChange, placeholder, hint, rows = 3 }) {
  return (
    <div>
      {label && <Label>{label}</Label>}
      <textarea value={value} onChange={e => onChange(e.target.value)}
        placeholder={placeholder} rows={rows}
        className="w-full bg-bg-2 border border-border-2 rounded-lg px-3 py-2 text-xs text-ink placeholder-ink-3 outline-none focus:border-accent font-mono resize-none"/>
      {hint && <p className="text-[10px] text-ink-3 mt-1">{hint}</p>}
    </div>
  )
}

function StatusBadge({ ok }) {
  return ok
    ? <span className="flex items-center gap-1 text-[10px] font-medium text-success bg-success/10 border border-success/20 px-2 py-0.5 rounded-full"><CheckCircle2 size={10}/>Aktif</span>
    : <span className="flex items-center gap-1 text-[10px] font-medium text-ink-3 bg-bg-4 border border-border px-2 py-0.5 rounded-full"><XCircle size={10}/>Belum Setup</span>
}

function Btn({ label, onClick, loading, variant = 'default', icon: Icon, small, disabled, full }) {
  return (
    <button onClick={onClick} disabled={loading || disabled}
      className={clsx('flex items-center justify-center gap-1.5 rounded-lg font-medium transition-all disabled:opacity-50',
        full ? 'w-full' : '',
        small ? 'px-2.5 py-1.5 text-[10px]' : 'px-3 py-2 text-xs',
        variant === 'primary' && 'bg-accent hover:bg-accent/80 text-white',
        variant === 'success' && 'bg-success/10 hover:bg-success/20 border border-success/30 text-success',
        variant === 'danger'  && 'bg-danger/10 hover:bg-danger/20 border border-danger/30 text-danger',
        variant === 'warn'    && 'bg-warn/10 hover:bg-warn/20 border border-warn/30 text-warn',
        variant === 'default' && 'bg-bg-4 hover:bg-bg-5 border border-border text-ink-2 hover:text-ink',
      )}>
      {loading ? <RefreshCw size={small ? 10 : 12} className="animate-spin"/> : Icon && <Icon size={small ? 10 : 12}/>}
      {label}
    </button>
  )
}

function CopyBtn({ text }) {
  const [ok, setOk] = useState(false)
  return (
    <button onClick={() => { copyToClipboard(text); setOk(true); setTimeout(() => setOk(false), 2000) }}
      className="p-1 rounded hover:bg-bg-5 text-ink-3 hover:text-ink transition-colors flex-shrink-0">
      {ok ? <Check size={11} className="text-success"/> : <Copy size={11}/>}
    </button>
  )
}

// ── Card collapsible ──────────────────────────────────────────
function Card({ icon, title, subtitle, configured, children, defaultOpen }) {
  const [open, setOpen] = useState(defaultOpen !== undefined ? defaultOpen : !configured)
  return (
    <div className="bg-bg-3 border border-border rounded-xl overflow-hidden">
      <button className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-bg-4/50 transition-colors"
        onClick={() => setOpen(!open)}>
        <div className="w-8 h-8 rounded-lg bg-bg-4 flex items-center justify-center text-lg flex-shrink-0">{icon}</div>
        <div className="flex-1 min-w-0 text-left">
          <div className="text-sm font-semibold text-ink">{title}</div>
          <div className="text-[10px] text-ink-3">{subtitle}</div>
        </div>
        <StatusBadge ok={configured}/>
        {open ? <ChevronUp size={14} className="text-ink-3 flex-shrink-0"/> : <ChevronDown size={14} className="text-ink-3 flex-shrink-0"/>}
      </button>
      {open && <div className="px-4 pb-4 pt-1 border-t border-border">{children}</div>}
    </div>
  )
}

// ── MaskedField — tampil masked + tombol Ganti ────────────────
function MaskedField({ masked, label, value, onChange, placeholder, hint, onSave, saving, isSecret = true }) {
  const [editing, setEditing] = useState(false)

  // Jika sudah terkonfigurasi & tidak sedang edit → tampilkan baris masked
  if (masked && !editing) {
    return (
      <div className="mt-3">
        <Label>{label}</Label>
        <div className="flex items-center gap-2 p-2.5 bg-bg-4 rounded-xl border border-border">
          <div className="flex-1 min-w-0">
            <div className="font-mono text-xs text-accent-2 truncate">{masked}</div>
          </div>
          <button onClick={() => setEditing(true)}
            className="text-[10px] text-ink-3 hover:text-accent-2 border border-border hover:border-accent/40 px-2.5 py-1 rounded-lg transition-colors flex-shrink-0">
            Ganti
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="mt-3 space-y-2.5">
      {masked && editing && (
        <div className="flex items-center justify-between text-[10px] p-2 bg-warn/8 border border-warn/25 rounded-lg">
          <span className="text-warn">Mengganti nilai yang tersimpan</span>
          <button onClick={() => { setEditing(false); onChange('') }} className="text-ink-3 hover:text-ink">✕ Batal</button>
        </div>
      )}
      {isSecret
        ? <SecretInput label={label} value={value} onChange={onChange} placeholder={placeholder} hint={hint}/>
        : <TextInput   label={label} value={value} onChange={onChange} placeholder={placeholder} hint={hint}/>
      }
      <Btn label="Simpan" onClick={() => { onSave(); !masked && setEditing(false) }}
        loading={saving} variant="primary" icon={Save} disabled={!value.trim()}/>
    </div>
  )
}

// ── Telegram Card ─────────────────────────────────────────────
function TelegramCard({ status, onSave, saving, onTest, testing }) {
  const [token, setToken]             = useState('')
  const [webhook, setWebhook]         = useState('')
  const [showTokenForm, setShowTF]    = useState(false)
  const [polling, setPolling]         = useState({ running: false, configured: false })
  const [pollingLoading, setPollLoad] = useState(false)
  const [botInfo, setBotInfo]         = useState(null)
  const timer = useRef(null)

  const configured = status?.telegram?.configured

  const loadPolling = async () => {
    try { const r = await intApi.pollingStatus(); setPolling(r) } catch {}
  }

  useEffect(() => {
    loadPolling()
    timer.current = setInterval(loadPolling, 5000)
    return () => clearInterval(timer.current)
  }, [])

  const handleStart = async () => {
    setPollLoad(true)
    try {
      const r = await intApi.startPolling()
      setBotInfo({ name: r.bot_name, username: r.username })
      toast.success(`🤖 Bot @${r.username} mulai berjalan!`)
      await loadPolling()
    } catch (e) { toast.error(`✗ ${e.message}`) }
    finally { setPollLoad(false) }
  }

  const handleStop = async () => {
    setPollLoad(true)
    try { await intApi.stopPolling(); setBotInfo(null); toast('⏹ Bot dihentikan', { icon: '⏹' }); await loadPolling() }
    catch (e) { toast.error(e.message) }
    finally { setPollLoad(false) }
  }

  return (
    <div className="bg-bg-3 border border-border rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3.5">
        <div className="w-8 h-8 rounded-lg bg-bg-4 flex items-center justify-center text-lg flex-shrink-0">✈️</div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-semibold text-ink">Telegram Bot</div>
          <div className="text-[10px] text-ink-3">Auto-reply via AI ke chat Telegram</div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <StatusBadge ok={configured}/>
          {polling.running && (
            <span className="flex items-center gap-1 text-[10px] font-medium text-sky-400 bg-sky-400/10 border border-sky-400/20 px-2 py-0.5 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse"/>Polling
            </span>
          )}
        </div>
      </div>

      <div className="px-4 pb-4 pt-2 border-t border-border">
        {/* Layout 2 kolom di desktop */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

          {/* Kiri: Token config */}
          <div className="space-y-3">
            {/* Tampilkan masked jika sudah ada, dengan opsi ganti */}
            {configured && status?.telegram?.token_masked && !showTokenForm ? (
              <div>
                <Label>Bot Token</Label>
                <div className="flex items-center gap-2 p-2.5 bg-bg-4 rounded-xl border border-border">
                  <div className="flex-1 min-w-0">
                    <div className="font-mono text-xs text-accent-2 truncate">{status.telegram.token_masked}</div>
                  </div>
                  <button onClick={() => setShowTF(true)}
                    className="text-[10px] text-ink-3 hover:text-accent-2 border border-border hover:border-accent/40 px-2.5 py-1 rounded-lg transition-colors flex-shrink-0">
                    Ganti
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-2.5">
                {showTokenForm && (
                  <div className="flex items-center justify-between text-[10px] p-2 bg-warn/8 border border-warn/25 rounded-lg">
                    <span className="text-warn">Mengganti token tersimpan</span>
                    <button onClick={() => { setShowTF(false); setToken('') }} className="text-ink-3 hover:text-ink">✕ Batal</button>
                  </div>
                )}
                <SecretInput label="Bot Token" value={token} onChange={setToken}
                  placeholder="1234567890:ABCDEFxxxx"
                  hint="Dari @BotFather → /newbot atau /token"/>
                <TextInput label="Webhook URL (opsional)" value={webhook} onChange={setWebhook}
                  placeholder="https://domain-kamu.com/api/integrations/telegram/webhook"
                  hint="Kosongkan untuk mode Polling (cocok localhost)" mono/>
                <div className="flex gap-2">
                  <Btn label="Simpan" onClick={() => {
                    if (!token.trim()) { toast.error('Isi token terlebih dahulu'); return }
                    onSave('telegram', { TELEGRAM_BOT_TOKEN: token, ...(webhook ? { TELEGRAM_WEBHOOK_URL: webhook } : {}) })
                    setShowTF(false); setToken(''); setWebhook('')
                  }} loading={saving} variant="primary" icon={Save}/>
                  <Btn label="Test" onClick={onTest} loading={testing} variant="default" icon={Send}/>
                </div>
              </div>
            )}

            {/* Panduan singkat */}
            <div className="bg-bg-4 rounded-xl p-3 text-[10px] space-y-1 text-ink-3">
              <div className="text-ink-2 font-semibold mb-1.5">📱 Cara setup:</div>
              {[
                ['Buka Telegram → cari', '@BotFather', ' → kirim /newbot'],
                ['Ikuti instruksi → copy token'],
                ['Tempel token di atas → Simpan'],
                ['Klik Start Bot di kanan →'],
              ].map((parts, i) => (
                <div key={i}>{i + 1}. {parts.map((p, j) => (
                  p.startsWith('@') || p.startsWith('/') ? <code key={j} className="font-mono text-accent-2">{p}</code> : p
                ))}</div>
              ))}
              <div className="pt-1 font-mono text-accent-2">/start /help /clear /model</div>
            </div>
          </div>

          {/* Kanan: Polling control */}
          <div className="space-y-3">
            <div className={clsx('rounded-xl border p-3.5', polling.running ? 'bg-sky-400/5 border-sky-400/20' : 'bg-bg-4 border-border')}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {polling.running ? <Wifi size={13} className="text-sky-400"/> : <WifiOff size={13} className="text-ink-3"/>}
                  <span className="text-xs font-semibold text-ink">
                    {polling.running ? 'Bot Aktif (Polling)' : 'Bot Tidak Aktif'}
                  </span>
                </div>
                {polling.running
                  ? <Btn label="Stop Bot" onClick={handleStop} loading={pollingLoading} variant="danger" icon={Square} small/>
                  : <Btn label="Start Bot" onClick={handleStart} loading={pollingLoading} variant="success" icon={Play} small disabled={!configured}/>
                }
              </div>

              {polling.running && botInfo && (
                <div className="text-[10px] text-sky-400 font-mono mb-1.5">🤖 @{botInfo.username} ({botInfo.name})</div>
              )}

              <div className="text-[10px] text-ink-3">
                {polling.running
                  ? 'Bot menerima & menjawab pesan secara otomatis via AI.'
                  : configured
                    ? 'Klik Start Bot untuk mulai menerima pesan dari Telegram.'
                    : 'Simpan token Bot dulu sebelum menjalankan.'
                }
              </div>
            </div>

            {!configured && (
              <div className="p-3 bg-accent/8 border border-accent/20 rounded-xl text-[10px] text-ink-2">
                <strong className="text-ink block mb-1">Tips:</strong>
                Mode Polling tidak memerlukan domain publik atau HTTPS — cocok untuk menjalankan di localhost / komputer rumah.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}


// ── CustomModelSection ────────────────────────────────────────
function CustomModelSection() {
  const [providers, setProviders] = useState([])
  const [loading, setLoading]     = useState(true)
  const [showAdd, setShowAdd]     = useState(false)
  const [acting, setActing]       = useState({})
  const [testResult, setTestResult] = useState(null)

  const emptyForm = { name: '', base_url: '', api_key: '', models: '', icon: '🔌' }
  const [form, setForm] = useState(emptyForm)
  const setF = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const ICON_OPTIONS = ['🔌', '🧠', '⚡', '🚀', '💡', '🌐', '🔮', '🤖', '🎯', '💎']

  const load = async () => {
    setLoading(true)
    try {
      const r = await intApi.listCustomModels()
      setProviders(r.providers || [])
    } catch {} finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleTestConnection = async () => {
    if (!form.base_url.trim() || !form.api_key.trim()) {
      toast.error('Isi Base URL dan API Key terlebih dahulu')
      return
    }
    setActing(a => ({ ...a, testConn: true }))
    setTestResult(null)
    try {
      const r = await intApi.testCustomConnection({
        base_url: form.base_url,
        api_key: form.api_key,
        models: form.models,
      })
      setTestResult({ status: 'ok', message: r.message, models: r.available_models })
      toast.success(r.message)
      // Auto-fill models jika belum diisi
      if (!form.models.trim() && r.available_models?.length > 0) {
        setF('models', r.available_models.slice(0, 5).join(','))
      }
    } catch (e) {
      setTestResult({ status: 'error', message: e.message })
      toast.error(`✗ ${e.message}`)
    } finally { setActing(a => ({ ...a, testConn: false })) }
  }

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Nama provider wajib diisi'); return }
    if (!form.base_url.trim()) { toast.error('Base URL wajib diisi'); return }
    if (!form.api_key.trim()) { toast.error('API Key wajib diisi'); return }
    if (!form.models.trim()) { toast.error('Minimal satu model harus diisi'); return }

    setActing(a => ({ ...a, save: true }))
    try {
      const r = await intApi.addCustomModel(form)
      if (r.models) useModelsStore.setState({ models: r.models })
      toast.success('✅ Provider berhasil ditambahkan!')
      setShowAdd(false)
      setForm(emptyForm)
      setTestResult(null)
      await load()
    } catch (e) { toast.error(e.message) }
    finally { setActing(a => ({ ...a, save: false })) }
  }

  const handleDelete = async (id) => {
    if (!confirm('Hapus provider ini? Semua model dari provider ini akan hilang.')) return
    setActing(a => ({ ...a, [id + '_del']: true }))
    try {
      const r = await intApi.deleteCustomModel(id)
      if (r.models) useModelsStore.setState({ models: r.models })
      toast.success('Provider dihapus')
      await load()
    } catch (e) { toast.error(e.message) }
    finally { setActing(a => ({ ...a, [id + '_del']: false })) }
  }

  const handleTest = async (id) => {
    setActing(a => ({ ...a, [id + '_test']: true }))
    try {
      const r = await intApi.testCustomModel(id)
      toast.success(`✅ ${r.message}`)
      await load()
    } catch (e) { toast.error(`✗ ${e.message}`) }
    finally { setActing(a => ({ ...a, [id + '_test']: false })) }
  }

  const STATUS_STYLE = {
    connected: { label: 'Tersambung', cls: 'text-success bg-success/10 border-success/20' },
    untested:  { label: 'Belum Ditest', cls: 'text-warn bg-warn/10 border-warn/20' },
    error:     { label: 'Error', cls: 'text-danger bg-danger/10 border-danger/20' },
  }

  return (
    <div className="bg-bg-3 border border-border rounded-xl overflow-hidden mt-4">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <span className="text-base">🔌</span>
          <span className="text-sm font-semibold text-ink">Custom Model Provider</span>
          {providers.length > 0 && <span className="text-[10px] bg-accent/15 text-accent-2 px-1.5 py-0.5 rounded-full">{providers.length}</span>}
        </div>
        <Btn label="+ Tambah Provider" onClick={() => { setShowAdd(!showAdd); setForm(emptyForm); setTestResult(null) }} variant="primary" icon={Plus} small/>
      </div>

      <div className="p-4 space-y-3">
        {/* Add Form Popup */}
        {showAdd && (
          <div className="bg-bg-4 border border-accent/25 rounded-xl p-4 space-y-3 animate-fade">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-ink">➕ Tambah Model AI Provider</span>
              <button onClick={() => { setShowAdd(false); setTestResult(null) }} className="text-ink-3 hover:text-ink text-xs">✕</button>
            </div>

            <div className="p-3 bg-accent/8 border border-accent/20 rounded-xl text-[10px] text-ink-3">
              <strong className="text-ink block mb-1">💡 Petunjuk:</strong>
              Tambahkan provider API yang kompatibel dengan format OpenAI (misal: Together AI, Groq, Fireworks, DeepInfra, OpenRouter, dll). Masukkan Base URL, API Key, dan nama model yang ingin digunakan.
            </div>

            {/* Icon picker */}
            <div>
              <Label>Ikon</Label>
              <div className="flex gap-1.5 flex-wrap">
                {ICON_OPTIONS.map(ic => (
                  <button key={ic} onClick={() => setF('icon', ic)}
                    className={clsx('w-8 h-8 rounded-lg flex items-center justify-center text-base border transition-all',
                      form.icon === ic ? 'border-accent bg-accent/10' : 'border-border bg-bg-3 hover:border-border-2')}>
                    {ic}
                  </button>
                ))}
              </div>
            </div>

            {/* Form */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <TextInput label="Nama Provider *" value={form.name} onChange={v => setF('name', v)}
                placeholder="Together AI, Groq, dll"/>
              <TextInput label="Base URL *" value={form.base_url} onChange={v => setF('base_url', v)}
                placeholder="https://api.together.xyz/v1" hint="Endpoint API (format OpenAI)" mono/>
            </div>

            <SecretInput label="API Key *" value={form.api_key} onChange={v => setF('api_key', v)}
              placeholder="sk-...atau token API provider"/>

            <TextInput label="Model (pisah koma) *" value={form.models} onChange={v => setF('models', v)}
              placeholder="llama-3.1-70b,mixtral-8x7b" hint="Nama model sesuai dokumentasi provider" mono/>

            {/* Test Connection */}
            <div className="flex items-center gap-2">
              <Btn label="Test Koneksi" onClick={handleTestConnection} loading={acting.testConn}
                variant="success" icon={Send}/>
              {testResult && (
                <div className={clsx('flex-1 text-[10px] px-3 py-2 rounded-lg font-medium',
                  testResult.status === 'ok' ? 'bg-success/10 text-success border border-success/20' : 'bg-danger/10 text-danger border border-danger/20')}>
                  {testResult.status === 'ok' ? '✅' : '❌'} {testResult.message}
                  {testResult.models?.length > 0 && (
                    <div className="mt-1 text-[9px] opacity-75">
                      Model: {testResult.models.slice(0, 5).join(', ')}{testResult.models.length > 5 ? ` +${testResult.models.length - 5} lagi` : ''}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Save */}
            <div className="flex items-center justify-end gap-2 pt-1">
              <Btn label="Batal" onClick={() => { setShowAdd(false); setTestResult(null) }} variant="default" small/>
              <Btn label="Simpan Provider" onClick={handleSave} loading={acting.save} variant="primary" icon={Save}
                disabled={!form.name.trim() || !form.base_url.trim() || !form.api_key.trim() || !form.models.trim()}/>
            </div>
          </div>
        )}

        {/* List */}
        {loading ? (
          <div className="text-xs text-ink-3 flex items-center gap-2 py-2"><RefreshCw size={11} className="animate-spin"/>Memuat...</div>
        ) : providers.length === 0 && !showAdd ? (
          <div className="text-center py-6 text-xs text-ink-3">
            <span className="text-2xl block mb-2">🔌</span>
            Belum ada custom provider. Klik "+ Tambah Provider" untuk menambahkan model AI dari provider lain seperti Together AI, Groq, Fireworks, dll.
          </div>
        ) : (
          <div className="space-y-2">
            {providers.map(p => {
              const st = STATUS_STYLE[p.status] || STATUS_STYLE.untested
              return (
                <div key={p.id} className="bg-bg-4 rounded-xl border border-border p-3">
                  <div className="flex items-start gap-2">
                    <span className="text-base flex-shrink-0 mt-0.5">{p.icon || '🔌'}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-semibold text-ink">{p.name}</span>
                        <span className={clsx('text-[9px] px-1.5 py-0.5 rounded-full font-medium border', st.cls)}>{st.label}</span>
                      </div>
                      <div className="flex items-center gap-1 mt-0.5">
                        <code className="text-[9px] text-ink-3 font-mono truncate max-w-xs">{p.base_url}</code>
                      </div>
                      <div className="text-[9px] text-ink-3 mt-0.5">
                        Model: {p.models} · Key: {p.api_key_masked || '••••'}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <Btn label="Test" onClick={() => handleTest(p.id)} loading={acting[p.id+'_test']} variant="success" icon={Send} small/>
                      <button onClick={() => handleDelete(p.id)} disabled={acting[p.id+'_del']}
                        className="p-1.5 rounded-lg text-ink-3 hover:text-danger hover:bg-danger/10 transition-colors disabled:opacity-50">
                        <Trash2 size={11}/>
                      </button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

// ── Provider meta ─────────────────────────────────────────────
const PROVIDER_META = {
  fonnte: { label: 'Fonnte',  color: 'bg-green-500/15 text-green-400',   emoji: '📱' },
  n8n:    { label: 'n8n',     color: 'bg-pink-500/15 text-pink-400',     emoji: '🔄' },
  make:   { label: 'Make',    color: 'bg-purple-500/15 text-purple-400', emoji: '⚙️' },
  zapier: { label: 'Zapier',  color: 'bg-orange-500/15 text-orange-400', emoji: '⚡' },
  custom: { label: 'Custom',  color: 'bg-bg-5 text-ink-3',               emoji: '🔗' },
}

// ── WebhookSection ────────────────────────────────────────────
function WebhookSection() {
  const [hooks, setHooks]         = useState([])
  const [templates, setTemplates] = useState([])
  const [loading, setLoad]        = useState(true)
  const [showAdd, setShowAdd]     = useState(false)
  const [showTpl, setShowTpl]     = useState(false)
  const [acting, setActing]       = useState({})
  const [testRes, setTestRes]     = useState({})
  const [editId, setEditId]       = useState(null)

  const emptyForm = { name:'', description:'', provider:'custom', url:'', method:'POST', secret:'', events:['message'], headers_json:'{}', body_template:'', enabled:true }
  const [form, setForm] = useState(emptyForm)
  const setF = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const setAct = (k, v) => setActing(a => ({ ...a, [k]: v }))

  const EVENT_OPTIONS = [
    { v: 'message', l: 'Setiap pesan' },
    { v: 'session_start', l: 'Sesi baru' },
    { v: 'rag_query', l: 'Query RAG' },
  ]

  const load = async () => {
    setLoad(true)
    try {
      const [h, t] = await Promise.allSettled([intApi.listWebhooks(), intApi.webhookTemplates()])
      if (h.status === 'fulfilled') setHooks(h.value.webhooks || [])
      if (t.status === 'fulfilled') setTemplates(t.value.templates || [])
    } finally { setLoad(false) }
  }

  useEffect(() => { load() }, [])

  const pm = p => PROVIDER_META[p] || PROVIDER_META.custom

  const applyTpl = (t) => {
    setForm({ ...emptyForm, provider: t.provider, name: t.name, description: t.description,
      url: t.url_hint, method: t.method, headers_json: t.headers, body_template: t.body, events: t.events })
    setShowTpl(false); setShowAdd(true)
  }

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Nama webhook wajib'); return }
    if (!form.url.trim())  { toast.error('URL wajib diisi'); return }
    setAct('save', true)
    try {
      editId ? await intApi.updateWebhook(editId, form) : await intApi.createWebhook(form)
      toast.success(editId ? 'Webhook diperbarui' : 'Webhook ditambahkan!')
      setShowAdd(false); setEditId(null); setForm(emptyForm)
      await load()
    } catch(e) { toast.error(e.message) }
    finally { setAct('save', false) }
  }

  const handleDelete = async (id) => {
    if (!confirm('Hapus webhook ini?')) return
    setAct(id+'_del', true)
    try { await intApi.deleteWebhook(id); toast.success('Dihapus'); await load() }
    catch(e) { toast.error(e.message) }
    finally { setAct(id+'_del', false) }
  }

  const handleTest = async (id) => {
    setAct(id+'_test', true); setTestRes(r => ({ ...r, [id]: null }))
    try {
      const r = await intApi.testWebhook(id)
      setTestRes(res => ({ ...res, [id]: r }))
      r.status === 'ok' ? toast.success(r.message) : toast.error(r.message)
    } catch(e) { toast.error(e.message) }
    finally { setAct(id+'_test', false) }
  }

  const handleEdit = (hook) => {
    setForm({ name: hook.name, description: hook.description||'', provider: hook.provider,
      url: hook.url, method: hook.method, secret: hook.secret||'', events: hook.events||['message'],
      headers_json: hook.headers_json||'{}', body_template: hook.body_template||'', enabled: hook.enabled })
    setEditId(hook.id); setShowAdd(true)
  }

  const toggleEvent = ev => setF('events', form.events.includes(ev) ? form.events.filter(e=>e!==ev) : [...form.events, ev])

  return (
    <div className="bg-bg-3 border border-border rounded-xl overflow-hidden mt-4">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <Webhook size={14} className="text-accent-2"/>
          <span className="text-sm font-semibold text-ink">Webhook Lanjutan</span>
          {hooks.length > 0 && <span className="text-[10px] bg-accent/15 text-accent-2 px-1.5 py-0.5 rounded-full">{hooks.length}</span>}
        </div>
        <div className="flex gap-2">
          <Btn label="Template" onClick={() => setShowTpl(!showTpl)} variant="default" icon={Zap} small/>
          <Btn label="+ Tambah" onClick={() => { setShowAdd(!showAdd); setEditId(null); setForm(emptyForm) }} variant="primary" icon={Plus} small/>
        </div>
      </div>

      <div className="p-4 space-y-3">
        {/* Template picker */}
        {showTpl && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
            {templates.map(t => (
              <button key={t.provider} onClick={() => applyTpl(t)}
                className="flex items-center gap-2 p-2.5 rounded-xl border border-border bg-bg-4 hover:border-accent/50 hover:bg-accent/5 transition-all text-left">
                <span className="text-base">{pm(t.provider).emoji}</span>
                <div className="min-w-0">
                  <div className="text-[11px] font-semibold text-ink truncate">{t.name}</div>
                  <div className="text-[9px] text-ink-3 truncate">{t.description}</div>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Add/Edit form */}
        {showAdd && (
          <div className="bg-bg-4 border border-accent/25 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-ink">{editId ? '✏️ Edit Webhook' : '➕ Tambah Webhook'}</span>
              <button onClick={() => { setShowAdd(false); setEditId(null) }} className="text-ink-3 hover:text-ink text-xs">✕</button>
            </div>

            {/* Provider */}
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(PROVIDER_META).map(([k, v]) => (
                <button key={k} onClick={() => setF('provider', k)}
                  className={clsx('flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-medium border transition-all',
                    form.provider === k ? 'border-accent bg-accent/10 text-accent-2' : 'border-border bg-bg-3 text-ink-3 hover:border-border-2')}>
                  <span>{v.emoji}</span>{v.label}
                </button>
              ))}
            </div>

            {/* Form grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <TextInput label="Nama Webhook *" value={form.name} onChange={v => setF('name', v)} placeholder="Fonnte WhatsApp"/>
              <TextInput label="Deskripsi" value={form.description} onChange={v => setF('description', v)} placeholder="Keterangan singkat"/>
            </div>

            <div>
              <Label>URL Endpoint *</Label>
              <div className="flex gap-2">
                <select value={form.method} onChange={e => setF('method', e.target.value)}
                  className="bg-bg-2 border border-border-2 rounded-lg px-2 py-2 text-xs text-ink outline-none focus:border-accent flex-shrink-0">
                  <option>POST</option><option>GET</option>
                </select>
                <input value={form.url} onChange={e => setF('url', e.target.value)}
                  placeholder="https://api.fonnte.com/send"
                  className="flex-1 bg-bg-2 border border-border-2 rounded-lg px-3 py-2 text-xs text-ink placeholder-ink-3 outline-none focus:border-accent font-mono"/>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <Label>Events</Label>
                <div className="flex flex-wrap gap-3">
                  {EVENT_OPTIONS.map(e => (
                    <label key={e.v} className="flex items-center gap-1.5 cursor-pointer">
                      <input type="checkbox" checked={form.events.includes(e.v)} onChange={() => toggleEvent(e.v)} className="accent-accent"/>
                      <span className="text-xs text-ink-2">{e.l}</span>
                    </label>
                  ))}
                </div>
              </div>
              <TextInput label="Custom Headers JSON" value={form.headers_json} onChange={v => setF('headers_json', v)}
                placeholder='{"Authorization": "Bearer xxx"}' mono/>
            </div>

            <Textarea label="Body Template (kosong = JSON otomatis)"
              value={form.body_template} onChange={v => setF('body_template', v)} rows={2}
              placeholder={'{"target":"08xx","message":"{{content}}"}'}
              hint="Variabel: {{content}} {{event}} {{model}} {{phone}}"/>

            {form.provider === 'fonnte' && (
              <div className="bg-green-500/8 border border-green-500/20 rounded-xl p-3 text-[10px] text-green-400 space-y-1">
                <div className="font-semibold">📱 Panduan Fonnte:</div>
                <div>1. Daftar di fonnte.com & hubungkan WhatsApp</div>
                <div>2. Headers: <code className="font-mono">{`{"Authorization": "TOKEN_FONNTE"}`}</code></div>
                <div>3. Body: <code className="font-mono">{`{"target":"08xx","message":"{{content}}"}`}</code></div>
              </div>
            )}

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <div onClick={() => setF('enabled', !form.enabled)}
                  className={clsx('w-8 h-4 rounded-full relative transition-colors', form.enabled ? 'bg-accent' : 'bg-bg-5 border border-border')}>
                  <div className={clsx('absolute top-0.5 w-3 h-3 rounded-full bg-white shadow transition-transform', form.enabled ? 'translate-x-4' : 'translate-x-0.5')}/>
                </div>
                <span className="text-xs text-ink-2">Aktifkan</span>
              </label>
              <Btn label={acting.save ? 'Menyimpan...' : (editId ? 'Update' : 'Simpan Webhook')}
                onClick={handleSave} loading={acting.save} variant="primary" icon={Save}/>
            </div>
          </div>
        )}

        {/* List */}
        {loading ? (
          <div className="text-xs text-ink-3 flex items-center gap-2 py-2"><RefreshCw size={11} className="animate-spin"/>Memuat...</div>
        ) : hooks.length === 0 ? (
          <div className="text-center py-6 text-xs text-ink-3">
            <Webhook size={22} className="mx-auto mb-2 opacity-30"/>
            Belum ada webhook. Klik "+ Tambah" atau pilih template.
          </div>
        ) : (
          <div className="space-y-2">
            {hooks.map(h => {
              const meta = pm(h.provider)
              const tr   = testRes[h.id]
              return (
                <div key={h.id} className={clsx('bg-bg-4 rounded-xl border p-3', h.enabled ? 'border-border' : 'border-border opacity-60')}>
                  <div className="flex items-start gap-2">
                    <span className="text-base flex-shrink-0 mt-0.5">{meta.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-semibold text-ink">{h.name}</span>
                        <span className={clsx('text-[9px] px-1.5 py-0.5 rounded-full font-medium', meta.color)}>{meta.label}</span>
                        {!h.enabled && <span className="text-[9px] bg-bg-5 text-ink-3 px-1.5 py-0.5 rounded-full">Nonaktif</span>}
                      </div>
                      <div className="flex items-center gap-1 mt-0.5">
                        <span className="text-[9px] font-mono bg-accent/10 text-accent-2 px-1 rounded">{h.method}</span>
                        <code className="text-[9px] text-ink-3 font-mono truncate max-w-xs">{h.url}</code>
                        <CopyBtn text={h.url}/>
                      </div>
                      <div className="text-[9px] text-ink-3 mt-0.5">
                        {h.events?.join(', ')}
                        {h.trigger_count > 0 && ` · ${h.trigger_count}× dipanggil`}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <Btn label="Test" onClick={() => handleTest(h.id)} loading={acting[h.id+'_test']} variant="success" icon={Send} small/>
                      <Btn label="Edit" onClick={() => handleEdit(h)} variant="default" small/>
                      <button onClick={() => handleDelete(h.id)} disabled={acting[h.id+'_del']}
                        className="p-1.5 rounded-lg text-ink-3 hover:text-danger hover:bg-danger/10 transition-colors disabled:opacity-50">
                        <Trash2 size={11}/>
                      </button>
                    </div>
                  </div>
                  {tr && (
                    <div className={clsx('mt-2 p-2 rounded-lg text-[10px] font-mono',
                      tr.status === 'ok' ? 'bg-success/8 text-success' : 'bg-danger/8 text-danger')}>
                      {tr.status === 'ok' ? '✓' : '✗'} {tr.message}
                      {tr.response && <div className="opacity-70 truncate mt-0.5">{tr.response}</div>}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

// ── Main ──────────────────────────────────────────────────────
export default function Integrations() {
  const [status,     setStatus]     = useState(null)
  const [loading,    setLoading]    = useState(true)
  const [saving,     setSaving]     = useState({})
  const [testing,    setTesting]    = useState({})
  const [reloading,  setReloading]  = useState(false)
  const [restarting, setRestarting] = useState(false)

  // API key state — selalu kosong, tidak pernah di-prefill
  const [openaiKey,      setOpenaiKey]      = useState('')
  const [anthropicKey,   setAnthropicKey]   = useState('')
  const [googleKey,      setGoogleKey]      = useState('')
  const [sumopodKey,     setSumopodKey]     = useState('')
  const [sumopodHost,    setSumopodHost]    = useState('')
  const [sumopodModels,  setSumopodModels]  = useState('')
  const [ollamaHost,     setOllamaHost]     = useState('')
  const [ollamaModels,   setOllamaModels]   = useState('')
  const [waToken,        setWaToken]        = useState('')
  const [waPhoneId,      setWaPhoneId]      = useState('')

  const load = async () => {
    try {
      const s = await intApi.status()
      setStatus(s)
      // Prefill hanya nilai non-secret (host, models) — bukan key/token
      if (s.sumopod?.host)   setSumopodHost(s.sumopod.host)
      if (s.sumopod?.models) setSumopodModels(s.sumopod.models)
      if (s.ollama?.host)    setOllamaHost(s.ollama.host)
      if (s.ollama?.models)  setOllamaModels(s.ollama.models)
      // Phone ID - tidak di-prefill, hanya tampilkan sebagai info
      // KEY & TOKEN tidak di-prefill agar form tetap kosong
    } catch {} finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  async function save(provider, fields) {
    setSaving(s => ({ ...s, [provider]: true }))
    try { 
      const r = await intApi.saveKey(provider, fields); 
      if (r.models) useModelsStore.setState({ models: r.models });
      toast.success(`✓ ${r.message}`); 
      await load() 
    }
    catch (e) { toast.error(e.message) }
    finally { setSaving(s => ({ ...s, [provider]: false })) }
  }

  async function testConn(provider, fn) {
    setTesting(s => ({ ...s, [provider]: true }))
    try {
      const r = await fn()
      if (provider === 'telegram')  toast.success(`✓ Bot: @${r.username}`)
      else if (provider === 'ollama')  toast.success(`✓ Ollama: ${r.count} model`)
      else if (provider === 'sumopod') toast.success(`✓ Sumopod OK`)
    } catch (e) { toast.error(`✗ ${e.message}`) }
    finally { setTesting(s => ({ ...s, [provider]: false })) }
  }

  if (loading) return (
    <div className="p-6 text-sm text-ink-3 flex items-center gap-2">
      <RefreshCw size={14} className="animate-spin"/>Memuat...
    </div>
  )

  return (
    <div className="p-4 md:p-6 max-w-full">
      {/* Header */}
      <div className="flex items-start justify-between mb-5 flex-wrap gap-3">
        <div>
          <h1 className="text-lg font-bold text-ink">Integrasi Platform</h1>
          <p className="text-xs text-ink-3 mt-0.5">API key & koneksi layanan eksternal</p>
        </div>
        <div className="flex items-center gap-2">
          <Btn label="Reload Model" onClick={async () => {
            setReloading(true)
            try { 
              const r = await intApi.reloadModels(); 
              if (r.models) useModelsStore.setState({ models: r.models });
              toast.success(`✓ ${r.message}`);
            }
            catch (e) { toast.error(e.message) } finally { setReloading(false) }
          }} loading={reloading} variant="success" icon={RefreshCw}/>
          <Btn label="Restart Server" onClick={async () => {
            if (!confirm('Restart server?')) return
            setRestarting(true)
            try { await intApi.restart(); toast.loading('Restarting...', { duration: 4000 }); await new Promise(r => setTimeout(r, 4000)); toast.success('Restart selesai!') }
            catch (e) { toast.error(e.message) } finally { setRestarting(false) }
          }} loading={restarting} variant="danger" icon={RotateCcw}/>
        </div>
      </div>

      <div className="flex items-start gap-2 p-3 mb-5 bg-accent/8 border border-accent/20 rounded-xl text-xs text-ink-3">
        <AlertCircle size={14} className="text-accent-2 flex-shrink-0 mt-0.5"/>
        API key tersimpan ke <code className="font-mono text-accent-2 bg-bg-4 px-1 rounded mx-1">.env</code>.
        Klik <strong className="text-ink mx-1">Reload Model</strong> untuk aktifkan tanpa restart.
      </div>

      {/* ── Messaging ── */}
      <div className="mb-2">
        <div className="text-[10px] text-ink-3 uppercase tracking-wider font-medium mb-2 px-1">💬 Messaging</div>
        <div className="space-y-3">
          <TelegramCard status={status} onSave={save} saving={saving.telegram}
            onTest={() => testConn('telegram', intApi.testTelegram)} testing={testing.telegram}/>

          <Card icon="💬" title="WhatsApp Business" subtitle="Meta Business API" configured={status?.whatsapp?.configured}>
            <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Access Token */}
              <MaskedField
                masked={status?.whatsapp?.token_masked}
                label="Access Token"
                value={waToken}
                onChange={setWaToken}
                placeholder=""
                hint="Meta Business Suite → WhatsApp → API Setup"
                onSave={() => save('whatsapp', { WHATSAPP_ACCESS_TOKEN: waToken })}
                saving={saving.whatsapp}
              />
              {/* Phone Number ID */}
              <MaskedField
                masked={status?.whatsapp?.phone_number_id && status.whatsapp.phone_number_id.length > 3 ? status.whatsapp.phone_number_id : null}
                label="Phone Number ID"
                value={waPhoneId}
                onChange={setWaPhoneId}
                placeholder=""
                hint="Temukan di Meta Business Suite → WhatsApp"
                onSave={() => save('whatsapp', { WHATSAPP_PHONE_NUMBER_ID: waPhoneId })}
                saving={saving.whatsapp}
                isSecret={false}
              />
            </div>
          </Card>
        </div>
      </div>

      {/* ── AI Models ── */}
      <div className="mb-2 mt-5">
        <div className="text-[10px] text-ink-3 uppercase tracking-wider font-medium mb-2 px-1">🤖 Model AI</div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">

          <Card icon="🧠" title="OpenAI" subtitle="GPT-4o, GPT-4o Mini" configured={status?.openai?.configured}>
            <MaskedField masked={status?.openai?.key_masked} label="API Key"
              value={openaiKey} onChange={setOpenaiKey} placeholder="sk-..."
              hint="platform.openai.com/api-keys"
              onSave={() => save('openai', { OPENAI_API_KEY: openaiKey })} saving={saving.openai}/>
          </Card>

          <Card icon="✨" title="Anthropic Claude" subtitle="Claude 3.5 Sonnet, Haiku" configured={status?.anthropic?.configured}>
            <MaskedField masked={status?.anthropic?.key_masked} label="API Key"
              value={anthropicKey} onChange={setAnthropicKey} placeholder="sk-ant-..."
              hint="console.anthropic.com"
              onSave={() => save('anthropic', { ANTHROPIC_API_KEY: anthropicKey })} saving={saving.anthropic}/>
          </Card>

          <Card icon="💎" title="Google Gemini" subtitle="Gemini 1.5 Pro, Flash" configured={status?.google?.configured}>
            <MaskedField masked={status?.google?.key_masked} label="API Key"
              value={googleKey} onChange={setGoogleKey} placeholder="AIza..."
              hint="aistudio.google.com"
              onSave={() => save('google', { GOOGLE_API_KEY: googleKey })} saving={saving.google}/>
          </Card>

          <Card icon="🚀" title="Sumopod" subtitle="OpenAI-compatible API" configured={status?.sumopod?.configured} defaultOpen={status?.sumopod?.configured}>
            <div className="mt-3 space-y-2.5">
              <MaskedField masked={status?.sumopod?.key_masked} label="API Key"
                value={sumopodKey} onChange={setSumopodKey} placeholder="sk-..."
                onSave={() => save('sumopod', { SUMOPOD_API_KEY: sumopodKey, SUMOPOD_HOST: sumopodHost, SUMOPOD_AVAILABLE_MODELS: sumopodModels })} saving={saving.sumopod}/>
              <TextInput label="API Host" value={sumopodHost} onChange={setSumopodHost} placeholder="https://ai.sumopod.com/v1" mono/>
              <TextInput label="Model tersedia (pisah koma)" value={sumopodModels} onChange={setSumopodModels} placeholder="seed-2-0-mini,gpt-5-nano" hint="Model di dropdown chat" mono/>
              <div className="flex gap-2">
                <Btn label="Simpan" onClick={() => save('sumopod', { SUMOPOD_HOST: sumopodHost, SUMOPOD_AVAILABLE_MODELS: sumopodModels })} loading={saving.sumopod} variant="primary" icon={Save}/>
                <Btn label="Test" onClick={() => testConn('sumopod', intApi.testSumopod)} loading={testing.sumopod} variant="success" icon={Send}/>
              </div>
            </div>
          </Card>

          <Card icon="🦙" title="Ollama (Lokal Gratis)" subtitle="Model AI di komputer sendiri" configured={status?.ollama?.configured}>
            <div className="mt-3 space-y-2.5">
              <TextInput label="Host" value={ollamaHost} onChange={setOllamaHost} placeholder="http://localhost:11434" mono/>
              <TextInput label="Model manual (kosongkan = auto-detect)" value={ollamaModels} onChange={setOllamaModels} placeholder="llama3.1,mistral" mono/>
              <div className="flex gap-2">
                <Btn label="Simpan" onClick={() => save('ollama', { OLLAMA_HOST: ollamaHost, OLLAMA_AVAILABLE_MODELS: ollamaModels })} loading={saving.ollama} variant="primary" icon={Save}/>
                <Btn label="Test" onClick={() => testConn('ollama', intApi.testOllama)} loading={testing.ollama} variant="success" icon={Send}/>
              </div>
            </div>
          </Card>

        </div>

        {/* Custom Model Providers */}
        <CustomModelSection/>
      </div>

      {/* ── Webhook ── */}
      <div className="mt-5">
        <div className="text-[10px] text-ink-3 uppercase tracking-wider font-medium mb-2 px-1">🔗 Webhook & Otomasi</div>
        <WebhookSection/>
      </div>

      {/* ── API Endpoints ── */}
      <div className="mt-5 bg-bg-3 border border-border rounded-xl p-4">
        <h2 className="text-sm font-semibold text-ink mb-3">🔌 API Endpoints</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
          {[
            { m:'POST', p:'/api/auth/login',                         d:'Login, dapat token' },
            { m:'POST', p:'/api/chat/send',                          d:'Kirim pesan (streaming)' },
            { m:'POST', p:'/api/rag/upload',                         d:'Upload dokumen' },
            { m:'POST', p:'/api/integrations/telegram/start-polling',d:'Start Telegram bot' },
            { m:'POST', p:'/api/integrations/telegram/stop-polling', d:'Stop Telegram bot' },
            { m:'POST', p:'/api/integrations/reload-models',         d:'Reload model tanpa restart' },
            { m:'GET',  p:'/api/models/',                            d:'List model aktif' },
            { m:'GET',  p:'/api/health',                             d:'Health check' },
          ].map(ep => (
            <div key={ep.p} className="flex items-center gap-2 p-2 bg-bg-4 rounded-lg">
              <span className={clsx('text-[10px] font-mono font-bold px-1.5 py-0.5 rounded flex-shrink-0',
                ep.m==='GET' ? 'bg-success/15 text-success' : 'bg-accent/15 text-accent-2')}>{ep.m}</span>
              <span className="text-[10px] font-mono text-ink-2 flex-1 truncate">{ep.p}</span>
              <span className="text-[10px] text-ink-3 hidden lg:block">{ep.d}</span>
            </div>
          ))}
        </div>
        <a href="/docs" target="_blank" className="inline-flex items-center gap-1 mt-3 text-xs text-accent-2 hover:underline">
          📖 Buka Swagger Docs →
        </a>
      </div>
    </div>
  )
}
