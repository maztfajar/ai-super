import { useEffect, useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../hooks/useApi'
import { 
  MessageSquare, 
  Activity, 
  BookOpen, 
  Repeat2, 
  Download, 
  Calendar, 
  TrendingUp, 
  Bot, 
  Zap,
  LayoutDashboard,
  Clock,
  AlertCircle,
  ChevronRight,
  Sparkles,
  Cpu,
  BrainCircuit,
  Command,
  CloudLightning,
  Atom
} from 'lucide-react'
import clsx from 'clsx'

// ── Visual Assets (SVG Backgrounds) ───────────────────────────

const WavePath = () => (
  <svg className="absolute inset-0 w-full h-full opacity-20" preserveAspectRatio="none" viewBox="0 0 400 100">
    <path d="M0 80 C 100 80, 150 20, 200 50 S 300 80, 400 20 V 100 H 0 Z" fill="url(#wave-grad)" />
    <defs>
      <linearGradient id="wave-grad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="currentColor" stopOpacity="0.5" />
        <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
      </linearGradient>
    </defs>
  </svg>
)

const ECGPath = () => (
  <svg className="absolute inset-0 w-full h-full opacity-20" preserveAspectRatio="none" viewBox="0 0 400 100">
    <path d="M0 50 L 50 50 L 60 20 L 75 80 L 90 50 L 140 50 L 150 10 L 165 90 L 180 50 L 400 50" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="1000" className="animate-draw" />
  </svg>
)

const NodeNetwork = () => (
  <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 100 100">
    <circle cx="20" cy="30" r="2" fill="currentColor" />
    <circle cx="50" cy="20" r="2" fill="currentColor" />
    <circle cx="80" cy="40" r="2" fill="currentColor" />
    <circle cx="40" cy="70" r="2" fill="currentColor" />
    <circle cx="70" cy="80" r="2" fill="currentColor" />
    <line x1="20" y1="30" x2="50" y2="20" stroke="currentColor" strokeWidth="0.5" />
    <line x1="50" y1="20" x2="80" y2="40" stroke="currentColor" strokeWidth="0.5" />
    <line x1="80" y1="40" x2="70" y2="80" stroke="currentColor" strokeWidth="0.5" />
    <line x1="40" y1="70" x2="70" y2="80" stroke="currentColor" strokeWidth="0.5" />
    <line x1="20" y1="30" x2="40" y2="70" stroke="currentColor" strokeWidth="0.5" />
    <line x1="40" y1="70" x2="50" y2="20" stroke="currentColor" strokeWidth="0.5" />
  </svg>
)

const FlowchartIcon = () => (
  <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 100 100">
    <rect x="10" y="10" width="15" height="10" rx="2" fill="currentColor" />
    <rect x="40" y="10" width="15" height="10" rx="2" fill="currentColor" />
    <rect x="75" y="10" width="15" height="10" rx="2" fill="currentColor" />
    <rect x="40" y="40" width="15" height="10" rx="2" fill="currentColor" />
    <path d="M25 15 H 40 M55 15 H 75 M47.5 20 V 40" stroke="currentColor" strokeWidth="1" />
  </svg>
)

// ── Components ────────────────────────────────────────────────

function Card({ children, className }) {
  return (
    <div className={clsx("bg-bg-3 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-3xl relative group/card", className)}>
      <div className="relative z-10 h-full">{children}</div>
    </div>
  )
}

function SystemOrb({ label, value, percent, subtext, colorClass, glowClass }) {
  const radius = 36
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (percent / 100) * circumference

  return (
    <div className="flex flex-col items-center gap-4 group/orb">
      <div className="relative w-28 h-28 flex items-center justify-center">
        {/* Organic Aura Background */}
        <div className={clsx("absolute inset-2 rounded-full blur-2xl opacity-20 group-hover/orb:opacity-40 transition-opacity animate-pulse", glowClass)} />
        
        {/* SVG Gauge */}
        <svg className="w-full h-full -rotate-90 drop-shadow-[0_0_8px_rgba(0,0,0,0.5)]" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r={radius} fill="transparent" stroke="currentColor" strokeWidth="6" className="text-ink/5" />
          <circle 
            cx="50" cy="50" r={radius} fill="transparent" stroke="currentColor" strokeWidth="6" 
            strokeDasharray={circumference} 
            strokeDashoffset={offset} 
            strokeLinecap="round"
            className={clsx("transition-all duration-1000 ease-out drop-shadow-[0_0_6px_currentColor]", colorClass)} 
          />
        </svg>

        {/* Center Text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-0">
          <span className="text-lg font-black text-ink tracking-tighter leading-none">{Math.round(percent)}%</span>
        </div>
      </div>

      <div className="text-center space-y-0.5">
        <div className="text-[10px] font-black text-ink uppercase tracking-widest">{label}</div>
        <div className="text-[7px] font-bold text-ink-3 uppercase tracking-tighter opacity-60 truncate max-w-[80px]">{subtext}</div>
      </div>
    </div>
  )
}

function ModelIcon({ name = '' }) {
  const n = name.toLowerCase()
  let Icon = Bot
  let grad = "from-blue-600 to-cyan-400"
  
  if (n.includes('gpt')) { Icon = Sparkles; grad = "from-emerald-600 to-teal-400" }
  else if (n.includes('claude') || n.includes('anthropic')) { Icon = Zap; grad = "from-orange-600 to-amber-400" }
  else if (n.includes('llama') || n.includes('meta')) { Icon = BrainCircuit; grad = "from-purple-600 to-indigo-400" }
  else if (n.includes('gemini') || n.includes('google')) { Icon = CloudLightning; grad = "from-blue-600 to-indigo-400" }
  else if (n.includes('deepseek') || n.includes('r1')) { Icon = Atom; grad = "from-rose-600 to-pink-400" }
  else if (n.includes('seed') || n.includes('sumo')) { Icon = Cpu; grad = "from-cyan-600 to-blue-400" }
  else if (n.includes('auto')) { Icon = Command; grad = "from-slate-600 to-slate-400" }

  return (
    <div className="relative shrink-0 group/icon">
      <div className={clsx("absolute inset-0 bg-gradient-to-br rounded-xl blur-md opacity-30 group-hover/icon:opacity-60 transition-opacity", grad)} />
      <div className={clsx("w-9 h-9 rounded-xl flex items-center justify-center bg-bg-4 relative z-10 overflow-hidden shadow-inner border-0")}>
        <div className={clsx("absolute inset-0 bg-gradient-to-br opacity-20", grad)} />
        <Icon size={16} className={clsx("relative z-10 transition-transform group-hover/icon:scale-110", grad.split(' ')[0].replace('from-', 'text-'))} />
      </div>
    </div>
  )
}

function StatCard({ label, value, subtext, icon: Icon, colorClass, glowClass, bgComp: BgComp }) {
  return (
    <Card className={clsx("p-6 transition-all duration-500 group", glowClass)}>
      {/* Dynamic Background Asset */}
      {BgComp && <div className={clsx("absolute inset-0 pointer-events-none", colorClass.replace('bg-', 'text-'))}><BgComp/></div>}
      
      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="flex items-center gap-2">
          <div className={clsx("w-1 h-3 rounded-full", colorClass)} />
          <h3 className="text-[10px] font-black text-ink-3 uppercase tracking-[0.2em]">{label}</h3>
        </div>
        <div className={clsx("p-2 rounded-xl bg-opacity-10", colorClass, colorClass.replace('bg-', 'text-'))}>
          <Icon size={16} />
        </div>
      </div>
      
      <div className="text-4xl font-black text-ink tracking-tighter relative z-10">{value}</div>
      <div className="flex items-center gap-1.5 mt-3 relative z-10">
        <TrendingUp size={12} className="text-success" />
        <p className="text-[10px] font-bold text-ink-3 tracking-wide">{subtext}</p>
      </div>
    </Card>
  )
}

function OverviewChart({ data, metric }) {
  if (!data || data.length === 0) return <div className="h-[180px] flex items-center justify-center text-xs text-ink-3">Menunggu data...</div>
  
  const getVal = (d) => {
    if (metric === 'Pesan') return d.messages
    if (metric === 'Token') return d.tokens
    if (metric === 'Latensi') return 30 + (d.messages % 20) // Simulated
    return 0.1 // Error
  }

  const maxVal = Math.max(...data.map(d => getVal(d)), 1)
  const colors = ["bg-gradient-to-t from-blue-600 to-blue-400", "bg-gradient-to-t from-emerald-600 to-emerald-400", "bg-gradient-to-t from-purple-600 to-purple-400", "bg-gradient-to-t from-orange-600 to-orange-400"]

  return (
    <div className="relative h-[180px] w-full mt-6 px-2">
      <ScanningLine />
      <div className="flex items-end justify-between gap-3 md:gap-6 h-full">
        {data.map((item, i) => {
          const val = getVal(item)
          return (
            <div key={i} className="flex flex-col items-center flex-1 h-full relative group">
              <div className="absolute -top-12 px-3 py-1.5 bg-bg/90 rounded-xl shadow-2xl text-[10px] font-black text-ink opacity-0 group-hover:opacity-100 transition-all transform group-hover:-translate-y-2 z-30 backdrop-blur-md">
                {val.toLocaleString()} {metric}
              </div>
              
              <div className="w-full bg-ink/5 rounded-t-2xl relative overflow-hidden h-full">
                <div 
                  className={clsx("absolute bottom-0 w-full transition-all duration-1000 ease-in-out rounded-t-xl group-hover:brightness-125", colors[i % colors.length])}
                  style={{ height: `${(val / maxVal) * 100}%`, minHeight: '6px' }}
                />
              </div>
              <div className="text-[9px] font-black text-ink-3 mt-4 uppercase tracking-widest opacity-60 group-hover:opacity-100">
                {item.label}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function SystemMonitor({ system, cpuHistory }) {
  if (!system) return null
  const gpu = system.gpu && system.gpu.length > 0 ? system.gpu[0] : null
  
  return (
    <Card className="p-8 bg-gradient-to-br from-bg-3 to-bg-4 h-[320px] flex flex-col items-center justify-center">
       <div className="flex w-full items-center justify-between gap-4 h-full">
          <SystemOrb 
            label="CPU" 
            percent={system.cpu.percent} 
            subtext="8-Core Turbo" 
            colorClass="text-blue-500" 
            glowClass="bg-blue-500" 
          />
          <SystemOrb 
            label="RAM" 
            percent={system.memory.percent} 
            subtext={`${system.memory.used_mb}MB / 16GB`} 
            colorClass="text-emerald-500" 
            glowClass="bg-emerald-500" 
          />
          <SystemOrb 
            label="DISK" 
            percent={system.disk.percent} 
            subtext={`${system.disk.used_gb}GB / 512GB`} 
            colorClass="text-purple-500" 
            glowClass="bg-purple-500" 
          />
          <SystemOrb 
            label="SWAP" 
            percent={system.swap.percent} 
            subtext="ZRAM Optimizing" 
            colorClass="text-amber-500" 
            glowClass="bg-amber-500" 
          />
          <SystemOrb 
            label="GPU" 
            percent={gpu ? gpu.util_pct : 0} 
            subtext={gpu ? `${gpu.temp_c}°C ACTIVE` : 'INACTIVE'} 
            colorClass="text-rose-500" 
            glowClass="bg-rose-500" 
          />
       </div>
    </Card>
  )
}

// ── Main Page ──────────────────────────────────────────────────

export default function Dashboard() {
  const [data, setData] = useState(null)
  const [system, setSystem] = useState(null)
  const [loading, setLoading] = useState(true)
  const [metric, setMetric] = useState('Pesan')
  const navigate = useNavigate()
  const scrollRef = useRef(null)
  const [cpuHistory, setCpuHistory] = useState(Array(20).fill(0))

  useEffect(() => {
    const fetch = () => api.dashboard().then(setData).catch(console.error).finally(() => setLoading(false))
    fetch()
    const int = setInterval(fetch, 10000)
    return () => clearInterval(int)
  }, [])

  useEffect(() => {
    const fetchSys = async () => {
      try {
        const s = await api.systemStats()
        if (s) {
          setSystem(s)
          setCpuHistory(prev => [...prev.slice(1), s.cpu.percent])
        }
      } catch(e) {}
    }
    fetchSys()
    const int = setInterval(fetchSys, 3000)
    return () => clearInterval(int)
  }, [])

  const downloadReport = () => {
    if (!data) return
    const csv = "Model,Requests,Tokens,Latency,ErrorRate\n" + 
      data.usage.map(u => `${u.model},${u.count},${u.tokens},${u.latency}ms,${u.error_rate}%`).join("\n")
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `ai-super-assistant-report-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  if (loading) return (
    <div className="p-8 flex flex-col items-center justify-center min-h-[70vh] gap-6 text-accent">
      <div className="w-20 h-20 border-4 border-t-transparent border-accent rounded-full animate-spin" />
      <span className="text-sm font-black uppercase tracking-[0.4em] animate-pulse">Synchronizing Grid...</span>
    </div>
  )

  const stats = data?.stats || {}
  const timeline = data?.timeline || []
  const usage = data?.usage || []
  const logs = data?.logs || []

  const chartData = timeline.map(t => ({
    label: t.day.split('-').slice(1).join('/'),
    messages: t.messages,
    tokens: t.tokens
  }))

  return (
    <div className="p-4 md:p-10 w-full max-w-full space-y-8 relative overflow-hidden">
      
      {/* Background Particles (VFX) */}
      <div className="fixed inset-0 pointer-events-none opacity-20 z-0">
        {[...Array(30)].map((_, i) => (
          <div key={i} className="absolute rounded-full bg-white animate-float" style={{
            width: Math.random() * 3 + 'px',
            height: Math.random() * 3 + 'px',
            left: Math.random() * 100 + '%',
            top: Math.random() * 100 + '%',
            animationDelay: Math.random() * 5 + 's',
            animationDuration: (Math.random() * 10 + 10) + 's'
          }} />
        ))}
      </div>

      {/* ── Header ────────────────────────────────────────────── */}
      <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-8 relative z-10">
        <div className="space-y-2">
          <div className="flex items-center gap-3 text-accent transition-all hover:translate-x-1">
            <Bot size={22} className="animate-bounce" />
            <span className="text-xs font-black uppercase tracking-[0.5em] opacity-70">AT Super Agent</span>
          </div>
          <h1 className="text-5xl font-black tracking-tighter text-ink lg:text-7xl bg-clip-text text-transparent bg-gradient-to-r from-ink to-ink-3">Dashboard</h1>
        </div>
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-3 px-5 py-3.5 bg-bg-3 rounded-2xl text-xs font-black text-ink hover:bg-bg-4 transition-all shadow-2xl backdrop-blur-sm">
            <Calendar size={16} className="text-accent" /> Mar 20, 2026 - Mar 28, 2026
          </button>
          <button onClick={downloadReport} className="flex items-center gap-3 px-6 py-3.5 bg-gradient-to-r from-accent to-accent-2 text-white rounded-2xl text-xs font-black shadow-[0_10px_40px_rgba(var(--accent-rgb),0.4)] active:scale-95 transition-all">
            <Download size={16} /> DOWNLOAD LAPORAN
          </button>
        </div>
      </div>

      {/* ── StatCards Row ──────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
        <StatCard label="Total Pesan" value={stats.total_messages?.toLocaleString()} subtext="+24.1% dari rata-rata" icon={MessageSquare} colorClass="bg-blue-600" glowClass="hover:shadow-blue-500/20" bgComp={WavePath} />
        <StatCard label="Sesi Aktif" value={stats.total_sessions?.toLocaleString()} subtext="+102 sesi baru minggu ini" icon={Zap} colorClass="bg-emerald-600" glowClass="hover:shadow-emerald-500/20" bgComp={ECGPath} />
        <StatCard label="Kapasitas RAG" value={stats.total_docs?.toLocaleString()} subtext="+12 file diunggah hari ini" icon={BookOpen} colorClass="bg-orange-600" glowClass="hover:shadow-orange-500/20" bgComp={NodeNetwork} />
        <StatCard label="Workflow Run" value={stats.workflow_runs?.toLocaleString()} subtext="+1.2k jam eksekusi" icon={Repeat2} colorClass="bg-purple-600" glowClass="hover:shadow-purple-500/20" bgComp={FlowchartIcon} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 relative z-10">
        
        {/* Left Column Stack */}
        <div className="lg:col-span-8 flex flex-col gap-8">
          <Card className="p-8 bg-gradient-to-br from-bg-3 to-bg-4 h-[320px] flex flex-col">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
              <div className="space-y-1">
                <h2 className="text-2xl font-black text-ink tracking-tight">Overview Aktivitas</h2>
                <p className="text-[10px] font-bold text-ink-3 uppercase tracking-[0.3em] opacity-40">Statistik orkestrasi harian</p>
              </div>
              <div className="flex p-1 bg-bg/40 rounded-2xl backdrop-blur-xl border border-border/10 shadow-inner">
                {['Pesan', 'Token', 'Latensi', 'Error'].map(t => (
                  <button key={t} onClick={() => setMetric(t)} className={clsx("px-5 py-2 text-[10px] font-black tracking-widest transition-all rounded-xl", metric === t ? "bg-accent text-white shadow-lg" : "text-ink-3 hover:text-ink")}>
                    {t.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
            <OverviewChart data={chartData} metric={metric} />
          </Card>

          <SystemMonitor system={system} cpuHistory={cpuHistory} />
        </div>

        {/* Right Column (Orchestration) */}
        <Card className="lg:col-span-4 p-6 flex flex-col bg-gradient-to-b from-bg-3 to-ink/5 h-[672px]">
          <div className="mb-4 pl-2">
            <div className="flex items-center gap-3 mb-0.5">
              <h2 className="text-xl font-black text-ink tracking-tight">Orkestrasi AI</h2>
              <div className="w-2 h-2 rounded-full bg-success animate-pulse shadow-[0_0_8px_#10b981]" />
            </div>
            <p className="text-[9px] font-bold text-ink-3 uppercase tracking-widest opacity-40">Distribusi beban kerja</p>
          </div>
          
          <div className="flex-1 space-y-1 overflow-y-auto custom-scrollbar pr-2">
            {usage.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center opacity-20">
                <LayoutDashboard size={40} className="mb-4" />
                <span className="text-[9px] font-black uppercase tracking-widest">Sistem Standby</span>
              </div>
            ) : (
              usage.sort((a,b) => b.count - a.count).map((u, i) => (
                <div key={i} className="group flex items-center gap-4 p-3 rounded-xl hover:bg-bg-4 transition-all">
                  <ModelIcon name={u.model} />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-black text-ink truncate mb-0.5 tracking-tight group-hover:translate-x-1 transition-transform">{u.model.split('/').pop()}</div>
                    <div className="text-[8px] font-black text-ink-3 uppercase tracking-[0.2em] opacity-50">{u.model.split('/')[0]}</div>
                  </div>
                  <div className="flex flex-col items-end gap-0.5">
                    <div className="text-xs font-black text-accent">+{u.count}</div>
                    <div className="flex items-center gap-2">
                       <span className="text-[8px] font-bold text-ink-3">{u.latency}ms</span>
                       <span className="flex items-center gap-1 text-[8px] font-bold text-success truncate max-w-[40px]"><div className="w-1 h-1 rounded-full bg-success" /> {u.error_rate}%</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <button onClick={() => navigate('/chat')} className="mt-4 group w-full py-4 bg-ink text-bg rounded-xl text-[9px] font-black uppercase tracking-[0.3em] shadow-2xl hover:brightness-110 transition-all flex items-center justify-center gap-4 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
            <Bot size={16} className="text-accent group-hover:rotate-12 transition-transform" /> 
            <span>Luncurkan Agent</span>
          </button>
        </Card>
      </div>

      {/* ── Live Event Feed ───────────────────────────────────── */}
      <Card className="p-8 bg-bg-4/50 backdrop-blur-3xl relative z-10 transition-all hover:bg-bg-4/70 group">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
             <div className="p-2 rounded-xl bg-accent/20 text-accent"><Activity size={16} /></div>
             <h2 className="text-xl font-black text-ink tracking-tight uppercase tracking-widest">Live Event Feed</h2>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-success animate-ping" />
            <span className="text-[10px] font-black text-success uppercase tracking-widest">Streaming</span>
          </div>
        </div>
        
        <div className="space-y-4 font-mono">
          {logs.length === 0 ? (
            <div className="py-8 text-center text-[10px] text-ink-3 opacity-30 italic">Menunggu event sistem...</div>
          ) : (
            logs.map((log, i) => (
              <div key={i} className="flex items-center gap-4 text-[11px] group/item p-2 rounded-lg hover:bg-white/5 transition-colors">
                 <span className="text-ink-3">{new Date().toLocaleTimeString()}</span>
                 <div className="w-1.5 h-1.5 rounded-full bg-accent opacity-40" />
                 <span className={clsx("flex-1 text-ink-2 truncate", log.level === 'ERROR' && "text-warn")}>{log.text}</span>
                 <ChevronRight size={14} className="text-ink-3 opacity-0 group-hover/item:opacity-100 transition-opacity" />
              </div>
            ))
          )}
        </div>
      </Card>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes draw { to { stroke-dashoffset: 0; } }
        .animate-draw { stroke-dashoffset: 1000; animation: draw 10s linear infinite; }
        @keyframes float { 
          0%, 100% { transform: translateY(0) translateX(0); opacity: 0.1; }
          50% { transform: translateY(-100px) translateX(20px); opacity: 0.5; }
        }
        .animate-float { animation: float infinite linear; }
        @keyframes scan {
          0% { transform: translateY(0); opacity: 0; }
          50% { opacity: 1; }
          100% { transform: translateY(180px); opacity: 0; }
        }
        .animate-scan { animation: scan 3s linear infinite; }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(var(--accent-rgb), 0.2); border-radius: 10px; }
      `}} />

    </div>
  )
}
