"""
AI SUPER ASSISTANT — Memory Manager (Enhanced)
3-Layer Memory System:
  Layer 1: Short-term  → Redis (active context, TTL 24 jam)
  Layer 2: Long-term   → Database (riwayat chat permanen, fallback Redis)
  Layer 3: Behavioral  → Database (preferensi & kebiasaan user)
"""
import json
from typing import Optional, List
import structlog
from core.config import settings

log = structlog.get_logger()

# Batas riwayat yang dibawa ke konteks AI
CONTEXT_WINDOW   = 20   # maks pesan dibawa per request
DB_HISTORY_LIMIT = 50   # maks pesan diambil dari DB untuk seed Redis
REDIS_TTL        = 86400 * 7  # 7 hari (diperpanjang dari 1 hari)


class MemoryManager:
    def __init__(self):
        self.redis = None
        self._redis_available = False

    async def startup(self):
        try:
            import redis.asyncio as aioredis
            self.redis = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
            await self.redis.ping()
            self._redis_available = True
            log.info("Memory system (Redis) connected — TTL 7 hari")
        except Exception:
            self._redis_available = False
            log.warning("Redis tidak tersedia — pakai DB fallback untuk memory")

    # ── Layer 1: Short-term Redis ─────────────────────────────
    async def save_short_term(self, session_id: str, messages: list, ttl: int = REDIS_TTL):
        if self._redis_available and self.redis:
            try:
                key = "chat:ctx:" + session_id
                # Simpan maks CONTEXT_WINDOW * 2 pesan (user+assistant pairs)
                trimmed = messages[-(CONTEXT_WINDOW * 2):]
                await self.redis.setex(key, ttl, json.dumps(trimmed))
            except Exception as e:
                log.warning("Redis save error", error=str(e)[:80])

    async def get_short_term(self, session_id: str) -> list:
        if self._redis_available and self.redis:
            try:
                key  = "chat:ctx:" + session_id
                data = await self.redis.get(key)
                if data:
                    return json.loads(data)
            except Exception as e:
                log.warning("Redis get error", error=str(e)[:80])
        return []

    # ── Load history dari DB ke Redis (saat session dibuka) ───
    async def seed_from_db(self, session_id: str, user_id: str):
        """
        Ambil riwayat chat dari database dan masukkan ke Redis.
        Dipanggil saat session dibuka / Redis kosong.
        """
        try:
            from db.database import AsyncSessionLocal
            from db.models import Message
            from sqlmodel import select
            from sqlalchemy import desc

            async with AsyncSessionLocal() as db:
                result = await db.execute(
                    select(Message)
                    .where(Message.session_id == session_id)
                    .where(Message.user_id    == user_id)
                    .where(Message.role.in_(["user", "assistant"]))
                    .order_by(desc(Message.created_at))
                    .limit(DB_HISTORY_LIMIT)
                )
                msgs = result.scalars().all()

            if not msgs:
                return []

            # Balik urutan (terbaru di akhir)
            msgs = list(reversed(msgs))
            history = [
                {"role": m.role, "content": m.content}
                for m in msgs
                if m.content and m.content.strip()
            ]
            # Simpan ke Redis
            await self.save_short_term(session_id, history)
            log.info("Memory seeded from DB", session_id=session_id[:8], count=len(history))
            return history
        except Exception as e:
            log.warning("Seed from DB error", error=str(e)[:100])
            return []

    async def get_context(self, session_id: str, user_id: str) -> list:
        """
        Ambil konteks chat untuk dikirim ke AI.
        Prioritas: Redis → DB → kosong
        """
        # Coba Redis dulu
        history = await self.get_short_term(session_id)

        # Jika Redis kosong, ambil dari DB dan seed ke Redis
        if not history:
            history = await self.seed_from_db(session_id, user_id)

        return history[-CONTEXT_WINDOW:]  # batas window ke AI

    # ── Layer 3: Behavioral (DB) ──────────────────────────────
    async def save_preference(self, user_id: str, content: str,
                              memory_type: str = "behavioral"):
        try:
            from db.database import AsyncSessionLocal
            from db.models import UserMemoryEntry
            async with AsyncSessionLocal() as db:
                entry = UserMemoryEntry(
                    user_id=user_id,
                    memory_type=memory_type,
                    content=content,
                )
                db.add(entry)
                await db.commit()
        except Exception as e:
            log.warning("Save preference error", error=str(e)[:100])

    async def get_user_preferences(self, user_id: str) -> list:
        try:
            from db.database import AsyncSessionLocal
            from db.models import UserMemoryEntry
            from sqlmodel import select
            async with AsyncSessionLocal() as db:
                result = await db.execute(
                    select(UserMemoryEntry)
                    .where(UserMemoryEntry.user_id == user_id)
                    .order_by(UserMemoryEntry.created_at.desc())
                    .limit(10)
                )
                return result.scalars().all()
        except Exception:
            return []

    # ── Build system prompt ────────────────────────────────────
    async def build_system_prompt(self, user_id: str, session_id: str) -> str:
        prefs = await self.get_user_preferences(user_id)
        base = (
            "You are AI SUPER ASSISTANT, a helpful AI Super Assistant. "
            "You are personal, smart, and efficient. "
            "Answer in the same language the user uses. "
            "Be concise but complete. "
        )
        if prefs:
            pref_texts = [p.content for p in prefs[:5] if p.content]
            if pref_texts:
                base += "User preferences & context: " + "; ".join(pref_texts) + ". "
        return base

    # ── Save ke Redis + perpanjang TTL ────────────────────────
    async def save_chat_to_redis(self, session_id: str, role: str, content: str):
        existing = await self.get_short_term(session_id)
        existing.append({"role": role, "content": content})
        await self.save_short_term(session_id, existing)

    # ── Info memory untuk UI ──────────────────────────────────
    async def get_memory_info(self, session_id: str, user_id: str) -> dict:
        """Info singkat tentang state memory — untuk ditampilkan di UI."""
        redis_count = 0
        db_count    = 0
        try:
            history     = await self.get_short_term(session_id)
            redis_count = len(history)
        except Exception:
            pass
        try:
            from db.database import AsyncSessionLocal
            from db.models import Message
            from sqlmodel import select, func
            async with AsyncSessionLocal() as db:
                r = await db.execute(
                    select(func.count(Message.id))
                    .where(Message.session_id == session_id)
                )
                db_count = r.scalar() or 0
        except Exception:
            pass
        return {
            "redis_messages":    redis_count,
            "db_messages":       db_count,
            "redis_available":   self._redis_available,
            "context_window":    CONTEXT_WINDOW,
            "redis_ttl_days":    REDIS_TTL // 86400,
        }

    async def clear_session(self, session_id: str):
        """Reset konteks satu sesi (tanpa hapus dari DB)."""
        if self._redis_available and self.redis:
            try:
                await self.redis.delete("chat:ctx:" + session_id)
            except Exception:
                pass


memory_manager = MemoryManager()
